from odoo import _, api, models
from odoo.exceptions import ValidationError

class ProjectTask(models.Model):
    _inherit = "project.task"

    @api.model_create_multi
    def create(self, vals_list):
        return super().create(vals_list)

    def write(self, vals):

        # Only validate when stage changes
        if "stage_id" in vals:

            new_stage = self.env["project.task.type"].browse(vals["stage_id"])
            for task in self:

                current_stage = task.stage_id

                # Project Manager bypass for this stage
                if (
                    current_stage.allow_manager_bypass
                    and self.env.user.has_group("project.group_project_manager")
                ):
                    continue

                # Skip if same stage
                if current_stage == new_stage:
                    continue

                # Skip if no current stage
                if not current_stage:
                    continue

                allowed_stages = current_stage.allowed_next_stage_ids

                if not allowed_stages:
                    continue

                if new_stage not in allowed_stages:
                    raise ValidationError(
                        _("You cannot move the task from '%s' to '%s'.")
                        % (
                            current_stage.display_name,
                            new_stage.display_name,
                        )
                    )

        return super().write(vals)