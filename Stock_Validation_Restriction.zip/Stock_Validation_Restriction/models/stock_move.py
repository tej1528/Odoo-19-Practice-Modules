from odoo import models, _
from odoo.exceptions import UserError
import logging

_logger = logging.getLogger(__name__)


class StockMove(models.Model):
    _inherit = "stock.move"

    def write(self, vals):
        res = super().write(vals)

        # Quantity change thai hoy to j check karvu
        if "quantity" in vals:

            for move in self:

                # Delivery Order mate j check
                if move.picking_id.picking_type_id.code != "outgoing":
                    continue

                available_qty = self.env[
                    "stock.quant"
                ]._get_available_quantity(
                    move.product_id,
                    move.picking_id.location_id,
                )

                _logger.warning(
                    "STOCK CHECK => Product=%s | Available=%s | Entered=%s",
                    move.product_id.display_name,
                    available_qty,
                    move.quantity,
                )

                if move.quantity > available_qty:

                    raise UserError(
                        _(
                            "Not enough stock available.\n\n"
                            "Product: %s\n"
                            "On Hand Quantity: %s\n"
                            "Entered Quantity: %s"
                        )
                        % (
                            move.product_id.display_name,
                            available_qty,
                            move.quantity,
                        )
                    )

        return res

