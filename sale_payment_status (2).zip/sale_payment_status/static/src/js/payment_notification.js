/** @odoo-module **/
import { registry } from "@web/core/registry";

export const PaymentNotificationService = {
    dependencies: ["bus_service", "notification"],
    start(env, { bus_service, notification }) {
        bus_service.subscribe("payment_registered", (payload) => {
            notification.add(
                `Payment of ₹${payload.amount} has been registered for ${payload.sale_order} by ${payload.registered_by}.`,
                {
                    title: "Payment Registered",
                    type: "success",
                    sticky: true,
                }
            );
        });
        bus_service.start();
    },
};

registry.category("services").add(
    "payment_notification_service",
    PaymentNotificationService
);