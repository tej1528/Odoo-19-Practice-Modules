from odoo import models

class AccountPaymentRegister(models.TransientModel):
    _inherit = "account.payment.register"

    def action_create_payments(self):
        amount = self.amount
        res = super().action_create_payments()

        invoices = self.env["account.move"].browse(
            self.env.context.get("active_ids", [])
        )

        sale_orders = invoices.mapped("line_ids.sale_line_ids.order_id")
        if sale_orders:
            sale_orders._send_payment_notification(amount)

        return res