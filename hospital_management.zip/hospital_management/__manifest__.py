{
    'name': 'Hospital Management system',
    'version': '1.0',
    'category': 'Healthcare',
    'summary': 'Manage doctors and patients',
    'author': 'Tejash Ardeshna', #
    'license': 'LGPL-3',

    'depends': ['base', 'mail', 'base_setup', 'web', 'portal', 'website'], 
    'images': ['static/description/icon.png'],

    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'data/sequence.xml',
        'data/mail_templates.xml',
        'data/appointment_status_data.xml',
        'reports/appointment_report_template.xml',
        'reports/appointment_report.xml',
        'reports/appointment_report_Filtering_template.xml',
        'wizard/appointment_report_wizard.xml',
        'views/login_inherit.xml',
        'views/mobile_templates.xml',
        'views/res_partner_views.xml',
        'views/appointment_views.xml',
        'views/appointment_action.xml',
        'views/res_config_settings_view.xml',
        'views/specialization_views.xml',
        'views/portal_templates.xml',
        'views/portal_menu.xml',
        'views/menu.xml',
    ],

    'assets': {
        'web.assets_backend': [
            'hospital_management/static/src/css/hide_action.css',
            'hospital_management/static/src/js/processing_timer.js',
            'hospital_management/static/src/js/calendar_reload.js',
            'hospital_management/static/src/xml/processing_timer.xml',
        ],
        'web.assets_frontend': [
            'hospital_management/static/src/js/appointment_portal.js',
            'hospital_management/static/src/js/otp_login.js',
        ],
    },

    'installable': True,
    'application': True,
}