/** @odoo-module **/

import { registry } from "@web/core/registry";

const notificationAudio = new Audio("/sale_payment_status/static/src/audio/notification.mp3");
notificationAudio.volume = 1.0;

export const PaymentNotificationService = {
    dependencies: ["bus_service", "notification", "action"],

    start(env, { bus_service, notification, action }) {
        // Subscribe to payment notification channel
        bus_service.subscribe("payment_registered", (payload) => {
            // Play audio
            notificationAudio.currentTime = 0;
            notificationAudio.play().catch(() => { });

            // Show Toast Notification
            const closeNotification = notification.add(
                `Payment of ₹${payload.amount} has been registered for ${payload.sale_order} by ${payload.registered_by}.`,
                {
                    title: "Payment Registered",
                    type: "success",
                    sticky: true,
                    buttons: [
                        {
                            name: "Open Invoice",
                            primary: true,
                            onClick: async () => {
                                if (typeof closeNotification === "function") {
                                    closeNotification();
                                }
                                try {
                                    await action.doAction(payload.action);
                                } catch (_) {
                                    // Handle navigation silently if view closes
                                }
                            },
                        },
                    ],
                }
            );
        });
    },
};

registry.category("services").add("payment_notification_service", PaymentNotificationService);