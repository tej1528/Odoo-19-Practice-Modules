from odoo import models

class PosSession(models.Model):
    _inherit = 'pos.session'

    def _loader_params_pos_order(self):
        res = super()._loader_params_pos_order()
        res['search_params']['fields'].append('cashier_final')
        return res