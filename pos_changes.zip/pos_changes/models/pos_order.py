from odoo import models, fields, api


class PosOrder(models.Model):
    _inherit = "pos.order"

    global_discount_amount = fields.Float(
        string="Global Discount Amount",
        default=0.0
    )

    global_discount_percentage = fields.Float(
        string="Global Discount Percentage",
        default=0.0
    )

    cashier_final = fields.Char(
        string="Cashier"
    )

    discount_display = fields.Char(
        string="Discount",
        compute="_compute_discount_display",
    )

    @api.depends(
        "global_discount_amount",
        "global_discount_percentage"
    )
    def _compute_discount_display(self):

        for order in self:

            if order.global_discount_amount:

                order.discount_display = (
                    f"Discount ({order.global_discount_percentage:.0f}%) : "
                    f"{order.global_discount_amount:.2f}"
                )

            else:
                order.discount_display = "No Discount"

    @classmethod
    def _order_fields(cls, ui_order):

        vals = super()._order_fields(ui_order)

        session_id = vals.get("session_id")

        if session_id:

            from odoo import api, SUPERUSER_ID

            env = api.Environment(
                cls.env.cr,
                SUPERUSER_ID,
                {}
            )

            session = env["pos.session"].browse(
                session_id
            )

            default_cashier = (
                session.config_id.default_user_id
            )

            if default_cashier:

                vals["user_id"] = (
                    default_cashier.id
                )

                vals["cashier_final"] = (
                    default_cashier.name
                )

        vals.update({
            "global_discount_amount":
                ui_order.get(
                    "global_discount_amount",
                    0.0
                ),

            "global_discount_percentage":
                ui_order.get(
                    "global_discount_percentage",
                    0.0
                ),
        })

        return vals

    @api.model
    def create(self, vals):

        order = super().create(vals)

        default_cashier = (
            order.session_id.config_id.default_user_id
        )

        if default_cashier:

            order.write({
                "user_id": default_cashier.id,
                "cashier_final": default_cashier.name,
            })

        return order