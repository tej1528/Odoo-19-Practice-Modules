/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { useService } from "@web/core/utils/hooks";

import { ControlButtons }
    from "@point_of_sale/app/screens/product_screen/control_buttons/control_buttons";

import { DiscountPopup }
    from "@pos_changes/js/discount_popup";

patch(ControlButtons.prototype, {

    setup() {

        super.setup();

        this.dialog = useService("dialog");
    },

    async openAmountDiscountPopup() {

        console.log("🔥 Button Clicked");

        this.dialog.add(DiscountPopup, {

            close: (result) => {

                console.log("📦 Popup Result:", result);

                // CANCEL
                if (!result || !result.confirmed) {

                    console.log("❌ Cancelled");

                    return;
                }

                // ORDER
                const order = this.pos.get_order();

                console.log("🛒 Current Order:", order);

                if (!order) {

                    console.log("❌ Order Not Found");

                    return;
                }

                // TOTAL
                const total = order.get_total_with_tax();

                console.log("💰 Order Total:", total);

                if (total <= 0) {

                    alert("Order total is zero");

                    return;
                }

                const percent =
                    parseFloat(result.payload.percent) || 0;

                const amount =
                    parseFloat(result.payload.amount) || 0;

                console.log("📊 Percent:", percent);
                console.log("💵 Amount:", amount);

                let percentage = 0;

                // BOTH ENTERED
                if (percent > 0 && amount > 0) {

                    alert("Use either % OR Amount");

                    return;
                }

                // PERCENT
                if (percent > 0) {

                    percentage = percent;
                }

                // FIXED AMOUNT
                else if (amount > 0) {

                    percentage = (amount / total) * 100;
                }

                else {

                    alert("Enter discount value");

                    return;
                }

                console.log("✅ Final Discount %:", percentage);

                // ORDER LINES
                const lines = order.get_orderlines();

                console.log("📦 Order Lines:", lines);

                // APPLY DISCOUNT
                lines.forEach((line) => {

                    console.log(
                        "➡ Applying Discount To:",
                        line.get_product().display_name
                    );

                    line.set_discount(percentage);
                });

                // REFRESH
                order.trigger("change");

                if (typeof order.requestUpdate === "function") {

                    order.requestUpdate();
                }

                // NOTIFICATION
                this.pos.notification.add(
                    "Discount Applied Successfully",
                    3000
                );

                console.log("🎉 Discount Applied");
            },
        });
    },
});