/** @odoo-module **/

import { Component, onWillStart, onPatched, useState } from "@odoo/owl";
import { useService } from "@web/core/utils/hooks";
import { registry } from "@web/core/registry";
import { standardFieldProps } from "@web/views/fields/standard_field_props";

export class StatusSelection extends Component {
    static template = "project_task_status_management.StatusSelection";
    static props = { ...standardFieldProps };

    setup() {
        this.orm = useService("orm");
        this.state = useState({
            statuses: [],
            currentStatus: null,
        });
        this.lastStageId = false;

        onWillStart(async () => {
            await this.loadStatuses();
        });

        onPatched(async () => {
            const stage = this.props.record.data.stage_id;
            const stageId = stage?.id || stage?.resId || stage?.[0] || false;

            if (stageId !== this.lastStageId) {
                await this.loadStatuses();
            }
        });
    }

    async loadStatuses() {
        const stage = this.props.record.data.stage_id;
        if (!stage) {
            this.lastStageId = false;
            this.state.statuses = [];
            this.state.currentStatus = null;
            return;
        }

        const stageId = stage.id || stage.resId || stage[0];
        this.lastStageId = stageId;

        const statuses = await this.orm.call("project.task", "get_statuses", [], { stage_id: stageId });
        this.state.statuses = statuses;

        const value = this.props.record.data.status_id;
        const id = value ? (value.id || value.resId || value[0]) : false;

        const selected = id ? statuses.find(s => s.id === id) : null;

        if (selected) {
            this.state.currentStatus = selected;
        } else {
            if (statuses.length > 0) {
                const firstStatus = statuses[0];
                this.state.currentStatus = firstStatus;

                await this.props.record.update({
                    status_id: {
                        id: firstStatus.id,
                        display_name: firstStatus.name,
                    },
                });
            } else {
                this.state.currentStatus = null;
                await this.props.record.update({ status_id: false });
            }
        }
    }

    // કયા ચોક્કસ સ્ટેટસ આઇડી ની ઉપર લાઇન બતાવવી તેનું ડાયનેમિક લોજીક
    get dividerStatusId() {
        if (!this.state.statuses || this.state.statuses.length === 0) {
            return false;
        }

        // ૧. લિસ્ટમાંથી Done અથવા Done (Capital) શોધો
        const doneStatus = this.state.statuses.find(s =>
            s.name === 'Done' || s.name === 'DONE'
        );
        if (doneStatus) {
            return doneStatus.id;
        }

        // ૨. જો Done ન હોય, તો Canceled અથવા Cancel શોધો
        const cancelStatus = this.state.statuses.find(s =>
            s.name === 'Canceled' || s.name === 'CANCEL' || s.name === 'Cancel'
        );
        if (cancelStatus) {
            return cancelStatus.id;
        }

        return false;
    }

    get statuses() {
        return this.state.statuses;
    }

    get currentStatus() {
        return this.state.currentStatus;
    }

    get statusName() {
        return this.currentStatus ? this.currentStatus.name : "Select Status";
    }

    iconMap(icon) {
        if (!icon) return "fa-circle";
        const cleanIcon = icon.toLowerCase().trim();
        const mapping = {
            circle: "fa-circle",
            play: "fa-play",
            pause: "fa-pause",
            check: "fa-check",
            times: "fa-times",
            flag: "fa-flag",
            exclamation: "fa-exclamation-circle"
        };
        return mapping[cleanIcon] || "fa-circle";
    }

    colorMap(color) {
        return {
            secondary: "#6C757D", // In Progress - Standard Odoo Cool Grey
            primary: "#00A09D",   // Approved - Odoo Teal (ઓરિજિનલ ઓદૂ બ્રાન્ડ ગ્રીન/ટીલ)
            warning: "#E0A900",   // Changes Requested - Odoo Light Amber/Yellow
            danger: "#DC3545",    // Cancel - Odoo Red
            success: "#10B981",   // Done - Odoo Emerald Green (લાઈટ લીલો કલર)
        }[color] || "#6C757D";
    }

    bgColorMap(color) {
        return {
            secondary: "#ecf0f2",
            primary: "#e2f2ec",
            warning: "#fbf3e3",
            danger: "#fde8e8",
            success: "#e2f2ec",
        }[color] || "#ecf0f2";
    }

    async selectStatus(ev) {
        const statusId = Number(ev.currentTarget.dataset.id);
        const status = this.state.statuses.find(s => s.id === statusId);

        if (!status) return;

        this.state.currentStatus = status;
        await this.props.record.update({
            status_id: {
                id: status.id,
                display_name: status.name,
            },
        });
    }
}

export const statusSelectionField = {
    component: StatusSelection,
    supportedTypes: ["many2one"],
};

registry.category("fields").add("status_selection", statusSelectionField);