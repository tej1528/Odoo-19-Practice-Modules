from odoo import _, api, models, fields
from odoo.exceptions import ValidationError

class ProjectTask(models.Model):
    _inherit = "project.task"

    status_id = fields.Many2one(
        "project.task.status",
        string="Task Status",
        tracking=True,
    )

    @api.model_create_multi
    def create(self, vals_list):
        return super().create(vals_list)

    @api.model
    def get_statuses(self, stage_id):
        print("=" * 50)
        print("RPC Stage ID :", stage_id)

        stage = self.env["project.task.type"].browse(stage_id)

        print("Stage :", stage.name)
        print("Allowed Status IDs :", stage.allowed_status_ids.ids)

        result = [
            {
                "id": status.id,
                "name": status.name,
                "icon": status.icon,
                "icon_color": status.icon_color,
                "sequence": status.sequence,
            }
            for status in stage.allowed_status_ids.sorted("sequence")
        ]

        print("Result :", result)
        print("=" * 50)

        return result
    
    @api.onchange("stage_id")
    def _onchange_stage_id(self):
        for task in self:
            if task.stage_id.default_user_id:
                task.user_ids = [(6, 0, [task.stage_id.default_user_id.id])]

            if (
                task.status_id
                and task.status_id not in task.stage_id.allowed_status_ids
            ):
                task.status_id = False
        
    def write(self, vals):

        # Only validate when stage changes
        if "stage_id" in vals:

            new_stage = self.env["project.task.type"].browse(vals["stage_id"])
            for task in self:

                current_stage = task.stage_id

                # Project Manager bypass for this stage
                if (
                    current_stage.allow_manager_bypass
                    and self.env.user.has_group("project.group_project_manager")
                ):
                    continue

                # Skip if same stage
                if current_stage == new_stage:
                    continue

                # Skip if no current stage
                if not current_stage:
                    continue

                allowed_stages = current_stage.allowed_next_stage_ids

                if not allowed_stages:
                    continue

                if new_stage not in allowed_stages:
                    raise ValidationError(
                        _("You cannot move the task from '%s' to '%s'.")
                        % (
                            current_stage.display_name,
                            new_stage.display_name,
                        )
                    )

        return super().write(vals)