/** @odoo-module **/

import { Component, onWillStart } from "@odoo/owl";
import { useService } from "@web/core/utils/hooks";
import { registry } from "@web/core/registry";
import { standardFieldProps } from "@web/views/fields/standard_field_props";

export class StatusSelection extends Component {

    static template = "project_task_status_management.StatusSelection";

    static props = {
        ...standardFieldProps,
    };

    setup() {
        this.orm = useService("orm");

        // Stage allowed statuses
        this._statuses = [];

        // Currently selected status object
        this.currentStatusData = null;

        onWillStart(async () => {
            await this.loadStatuses();
        });
    }

    //---------------------------------------------------
    // Load Stage Statuses
    //---------------------------------------------------

    async loadStatuses() {

        const stage = this.props.record.data.stage_id;

        if (!stage) {
            this._statuses = [];
            return;
        }

        const stageId = stage.id || stage.resId || stage[0];

        if (!stageId) {
            this._statuses = [];
            return;
        }

        this._statuses = await this.orm.call(
            "project.task",
            "get_statuses",
            [stageId]
        );

        const value = this.props.record.data.status_id;

        if (value) {
            const id = value.id || value.resId || value[0];

            this.currentStatusData =
                this._statuses.find((s) => s.id === id) || null;
        }
    }

    //---------------------------------------------------
    // Allowed Statuses
    //---------------------------------------------------

    get statuses() {
        return this._statuses;
    }

    //---------------------------------------------------
    // Current Status
    //---------------------------------------------------

    get currentStatus() {

        if (this.currentStatusData) {
            return this.currentStatusData;
        }

        const value = this.props.record.data.status_id;

        if (!value) {
            return null;
        }

        const id = value.id || value.resId || value[0];

        return (
            this.statuses.find((status) => status.id === id) || null
        );
    }

    //---------------------------------------------------
    // Button Text
    //---------------------------------------------------

    get statusName() {

        if (this.currentStatus) {
            return this.currentStatus.name;
        }

        return "Select Status";
    }

    //---------------------------------------------------
    // FontAwesome Icon Mapping
    //---------------------------------------------------

    iconMap(icon) {

        const icons = {
            circle: "circle",
            play: "play",
            pause: "pause",
            check: "check",
            times: "times",
            flag: "flag",
        };

        return icons[icon] || "circle";
    }

    //---------------------------------------------------
    // Icon Color Mapping
    //---------------------------------------------------

    colorMap(color) {

        const colors = {
            secondary: "#6c757d",
            primary: "#0d6efd",
            warning: "#f0ad4e",
            danger: "#dc3545",
            success: "#198754",
        };

        return colors[color] || "#6c757d";
    }

    //---------------------------------------------------
    // Select Status
    //---------------------------------------------------

    async selectStatus(ev) {

        const statusId = Number(ev.currentTarget.dataset.id);

        const status = this.statuses.find(
            (s) => s.id === statusId
        );

        if (!status) {
            return;
        }

        // Update UI immediately
        this.currentStatusData = status;

        // Update record
        await this.props.record.update({
            status_id: {
                id: status.id,
                display_name: status.name,
            },
        });

        this.render();
    }
}

export const statusSelectionField = {
    component: StatusSelection,
    supportedTypes: ["many2one"],
};

registry.category("fields").add(
    "status_selection",
    statusSelectionField
);