{
    "name": "   ",
    "version": "19.0.1.0.0",
    "category": "Human Resources",
    "summary": "Show checkout summary dialog before checkout",
    "author": "Tejash Ardeshna",
    "license": "LGPL-3",
    "depends": ["hr_attendance", "hr_timesheet", "hr_holidays",],
    "data": [
    ],
    "assets": {
        # "web.assets_backend": [
        #     "hr_attendance_summary_dialog/static/src/js/*.js",
        #     "hr_attendance_summary_dialog/static/src/xml/*.xml",
        #     "hr_attendance_summary_dialog/static/src/scss/*.scss",
        # ],
    },
    "installable": True,
    "application": False,
    "auto_install": False,
}