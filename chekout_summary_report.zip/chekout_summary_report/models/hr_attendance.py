import logging
import pytz

from odoo import models, fields

_logger = logging.getLogger(__name__)


class HrAttendance(models.Model):
    _inherit = "hr.attendance"

    def _cron_auto_check_out(self):

        _logger.info("========== AUTO CHECKOUT START ==========")

        def check_in_tz(attendance):
            return attendance.check_in.astimezone(
                pytz.timezone(attendance.employee_id._get_tz())
            )

        to_verify = self.search([
            ("check_out", "=", False),
            ("employee_id.company_id.auto_check_out", "=", True),
            ("employee_id.resource_calendar_id.flexible_hours", "=", False),
        ])

        _logger.info("Attendances Found : %s", to_verify.ids)

        if not to_verify:
            _logger.info("No Open Attendance Found")
            return super()._cron_auto_check_out()

        to_verify_min_date = min(
            to_verify.mapped("check_in")
        ).replace(hour=0, minute=0, second=0)

        previous_attendances = self.search([
            ("employee_id", "in", to_verify.mapped("employee_id").ids),
            ("check_in", ">", to_verify_min_date),
            ("check_out", "!=", False),
        ])

        from collections import defaultdict

        mapped_previous_duration = defaultdict(lambda: defaultdict(float))

        for previous in previous_attendances:
            mapped_previous_duration[
                previous.employee_id
            ][check_in_tz(previous).date()] += previous.worked_hours

        for company in to_verify.employee_id.company_id:

            _logger.info("===================================")
            _logger.info("Company : %s", company.name)

            max_tol = company.auto_check_out_tolerance

            to_verify_company = to_verify.filtered(
                lambda a: a.employee_id.company_id == company
            )

            for att in to_verify_company:

                employee_timezone = pytz.timezone(
                    att.employee_id._get_tz()
                )

                check_in_datetime = check_in_tz(att)

                now_datetime = fields.Datetime.now().astimezone(
                    employee_timezone
                )

                current_attendance_duration = (
                    now_datetime - check_in_datetime
                ).total_seconds() / 3600

                previous_attendances_duration = mapped_previous_duration[
                    att.employee_id
                ][check_in_datetime.date()]

                expected_worked_hours = sum(
                    att.employee_id.resource_calendar_id.attendance_ids.filtered(
                        lambda a:
                        a.dayofweek == str(check_in_datetime.weekday())
                        and (
                            not a.two_weeks_calendar
                            or a.week_type
                            == str(a.get_week_type(check_in_datetime.date()))
                        )
                    ).mapped("duration_hours")
                )

                _logger.info("--------------------------------")
                _logger.info("Employee : %s", att.employee_id.name)
                _logger.info("Check In : %s", check_in_datetime)
                _logger.info("Now : %s", now_datetime)
                _logger.info("Worked : %s", current_attendance_duration)
                _logger.info("Previous Hours : %s", previous_attendances_duration)
                _logger.info("Expected Hours : %s", expected_worked_hours)
                _logger.info("Tolerance : %s", max_tol)

                condition = (
                    current_attendance_duration
                    + previous_attendances_duration
                    - max_tol
                ) > expected_worked_hours

                _logger.info("Condition : %s", condition)

                if condition:
                    _logger.info(">>>>>>>> AUTO CHECKOUT SHOULD HAPPEN <<<<<<<<")
                else:
                    _logger.info("Condition Failed")

        return super()._cron_auto_check_out()