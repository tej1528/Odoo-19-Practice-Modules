from odoo import models, fields, api
from odoo.exceptions import ValidationError
from odoo.fields import Command


class SaleOrderMergeWizard(models.TransientModel):
    _name = "sale.order.merge.wizard"
    _description = "Merge Sale Orders"

    source_order_ids = fields.Many2many(
        "sale.order",
        string="Selected Orders",
        readonly=True,
    )

    target_order_id = fields.Many2one(
        "sale.order",
        string="Merge Into",
        required=True,
    )

    delete_source = fields.Boolean(
        string="Delete Source Orders",
        default=True,
    )

    @api.onchange("source_order_ids")
    def _onchange_source_order_ids(self):
        return {
            "domain": {
                "target_order_id": [
                    ("id", "in", self.source_order_ids.ids)
                ]
            }
        }

    def action_merge(self):
        self.ensure_one()

        orders = self.source_order_ids

        if len(orders) < 2:
            raise ValidationError(
                "Select at least 2 quotations."
            )

        invalid_orders = orders.filtered(
            lambda o: o.state not in ["draft", "sent"]
        )

        if invalid_orders:
            raise ValidationError(
                "Only Draft and Quotation Sent orders can be merged."
            )

        partners = orders.mapped("partner_id")

        if len(partners) > 1:
            raise ValidationError(
                "Customer must be same for all quotations."
            )

        target_order = self.target_order_id

        source_orders = orders.filtered(
            lambda o: o.id != target_order.id
        )

        for order in source_orders:

            for line in order.order_line.filtered(
                lambda l: not l.display_type
            ):

                existing_line = target_order.order_line.filtered(
                    lambda l:
                    not l.display_type
                    and l.product_id == line.product_id
                    and l.price_unit == line.price_unit
                    and l.discount == line.discount
                    and set(l.tax_id.ids) == set(line.tax_id.ids)
                )

                if existing_line:

                    existing_line.product_uom_qty += line.product_uom_qty

                else:

                    target_order.write({
                        "order_line": [
                            Command.create({
                                "product_id": line.product_id.id,
                                "name": line.name,
                                "product_uom_qty": line.product_uom_qty,
                                "price_unit": line.price_unit,
                                "discount": line.discount,
                                "tax_id": [
                                    Command.set(line.tax_id.ids)
                                ],
                            })
                        ]
                    })

            if self.delete_source:
                order.unlink()

        return {
            "type": "ir.actions.act_window_close"
        }