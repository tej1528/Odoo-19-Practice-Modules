{
    "name": "Sale Order Merge",
    "version": "19.0.1.0.0",
    "category": "Sales",
    "summary": "Merge multiple quotations into one quotation",
    "description":"Merge multiple quotations",
    "author": "Tejash",
    "website": "",
    "license": "LGPL-3",

    "depends": ["sale",],

    "data": [
    "data/server_action.xml",
    "wizard/sale_order_merge_wizard_views.xml",
    "security/ir.model.access.csv",
],

    "installable": True,
    "application": False,
    "auto_install": False,
}