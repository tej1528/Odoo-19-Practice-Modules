from odoo import models
import logging

_logger = logging.getLogger(__name__)


class SaleOrder(models.Model):
    _inherit = "sale.order"

    def action_open_merge_wizard(self):
        _logger.warning("MERGE ACTION CALLED")

        return {
            "type": "ir.actions.act_window",
            "name": "Merge Orders",
            "res_model": "sale.order.merge.wizard",
            "view_mode": "form",
            "target": "new",
            "context": {
                "default_source_order_ids": self.ids,
            },
        }