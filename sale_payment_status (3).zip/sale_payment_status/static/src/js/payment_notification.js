/** @odoo-module **/

import { registry } from "@web/core/registry";

export const PaymentNotificationService = {
    dependencies: ["bus_service", "notification", "action"],
    start(env, { bus_service, notification, action }) {
        bus_service.subscribe("payment_registered", (payload) => {
            const audio = new Audio(
                "/sale_payment_status/static/src/audio/notification.mp3"
            );
            audio.volume = 1.0;
            audio.play().catch(() => { });
            const notif = notification.add(
                `Payment of ₹${payload.amount} has been registered for ${payload.sale_order} by ${payload.registered_by}.`,
                {
                    title: "Payment Registered",
                    type: "success",
                    sticky: true,
                    buttons: [
                        {
                            name: "Open Invoice",
                            primary: true,
                            onClick: () => {
                                notif();

                                if (payload.invoice_ids.length === 1) {
                                    action.doAction({
                                        type: "ir.actions.act_window",
                                        res_model: "account.move",
                                        res_id: payload.invoice_ids[0],
                                        views: [[false, "form"]],
                                        target: "current",
                                    });

                                } else {
                                    action.doAction({
                                        type: "ir.actions.act_window",
                                        name: "Invoices",
                                        res_model: "account.move",
                                        views: [[false, "list"], [false, "form"]],
                                        domain: [["id", "in", payload.invoice_ids]],
                                        target: "current",
                                    });
                                }
                            },
                        },
                    ],
                }
            );
        });
        bus_service.start();
    },
};

registry.category("services").add(
    "payment_notification_service",
    PaymentNotificationService
);