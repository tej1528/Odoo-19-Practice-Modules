from odoo import models
from odoo.http import request
import logging

_logger = logging.getLogger(__name__)


class IrHttp(models.AbstractModel):
    _inherit = "ir.http"

    @classmethod
    def _authenticate(cls, endpoint):

        result = super()._authenticate(endpoint)

        if not request.session.uid:
            return result

        restrict_login = (
            request.env['ir.config_parameter']
            .sudo()
            .get_param(
                'restrict_login.restrict_multiple_login',
                'False'
            )
        )

        force_new_login = (
            request.env['ir.config_parameter']
            .sudo()
            .get_param(
                'restrict_login.force_new_login',
                'False'
            )
        )

        # Logout logic only when both options enabled
        if (
            restrict_login != 'True'
            or force_new_login != 'True'
        ):
            return result

        user = request.env['res.users'].sudo().browse(
            request.session.uid
        )

        session_token = request.session.get(
            'restrict_login_token'
        )

        _logger.warning(
            "AUTH CHECK | user=%s | db_token=%s | session_token=%s",
            user.login,
            user.active_session_token,
            session_token,
        )

        # Browser opened before token system existed
        if not session_token:
            return result

        # Token mismatch => old browser
        if (
            user.active_session_token
            and user.active_session_token != session_token
        ):

            _logger.warning(
                "FORCE LOGOUT | user=%s",
                user.login,
            )

            request.session.logout(
                keep_db=True
            )

        return result